
function bigimg()
{
document.getElementById("i1").style.height="120px";
document.getElementById("i1").style.width="120px";
}
function normalimg()
{
document.getElementById("i1").style.height="60px";
document.getElementById("i1").style.width="60px";
}

function bigimg1()
{
document.getElementById("i2").style.height="120px";
document.getElementById("i2").style.width="120px";
}
function normalimg1()
{
document.getElementById("i2").style.height="60px";
document.getElementById("i2").style.width="60px";
}

function bigimg2()
{
document.getElementById("i3").style.height="120px";
document.getElementById("i3").style.width="120px";
}
function normalimg2()
{
document.getElementById("i3").style.height="60px";
document.getElementById("i3").style.width="60px";
}

function bigimg3()
{
document.getElementById("i4").style.height="120px";
document.getElementById("i4").style.width="120px";
}
function normalimg3()
{
document.getElementById("i4").style.height="60px";
document.getElementById("i4").style.width="60px";
}

function bigimg4()
{
document.getElementById("i5").style.height="120px";
document.getElementById("i5").style.width="120px";
}
function normalimg4()
{
document.getElementById("i5").style.height="60px";
document.getElementById("i5").style.width="60px";
}

